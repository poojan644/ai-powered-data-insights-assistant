"""
AI-Powered Data Insights Assistant
-----------------------------------
Upload a CSV/Excel file, get an AI-generated summary of trends and anomalies,
then ask follow-up questions about your data in plain English.

Built with: Streamlit + pandas + Anthropic Claude API
"""

import os
import json
import streamlit as st
import pandas as pd
from anthropic import Anthropic
from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------
load_dotenv()  # reads ANTHROPIC_API_KEY from a local .env file

st.set_page_config(page_title="AI Data Insights Assistant", page_icon="📊", layout="wide")

# The API key can come from .env (local dev) or Streamlit secrets (when deployed)
api_key = os.getenv("ANTHROPIC_API_KEY") or st.secrets.get("ANTHROPIC_API_KEY", None)

if not api_key:
    st.error("No API key found. Add ANTHROPIC_API_KEY to a .env file (see .env.example).")
    st.stop()

client = Anthropic(api_key=api_key)
MODEL = "claude-sonnet-5"  # swap to "claude-haiku-4-5-20251001" for a cheaper/faster model

# ---------------------------------------------------------------------------
# Helper: turn a dataframe into a compact text summary
# ---------------------------------------------------------------------------
# IMPORTANT BEGINNER LESSON:
# We never send the raw file to Claude. LLMs are bad at scanning thousands of
# rows themselves, and it wastes tokens (= money). Instead we use pandas to
# compute the stats, then send Claude a *summary* and ask it to reason about it.
# This is the core idea behind "AI + data tooling" (Claude doesn't replace
# pandas, it explains what pandas found).

def build_data_summary(df: pd.DataFrame) -> str:
    summary_parts = []

    summary_parts.append(f"Shape: {df.shape[0]} rows, {df.shape[1]} columns")
    summary_parts.append(f"Columns and types:\n{df.dtypes.to_string()}")

    null_counts = df.isnull().sum()
    nulls = null_counts[null_counts > 0]
    if len(nulls) > 0:
        summary_parts.append(f"Missing values:\n{nulls.to_string()}")
    else:
        summary_parts.append("Missing values: none")

    numeric_df = df.select_dtypes(include="number")
    if not numeric_df.empty:
        summary_parts.append(f"Numeric column statistics:\n{numeric_df.describe().to_string()}")

    categorical_df = df.select_dtypes(include="object")
    if not categorical_df.empty:
        cat_summary = []
        for col in categorical_df.columns[:10]:  # cap to avoid huge prompts
            top_values = categorical_df[col].value_counts().head(5)
            cat_summary.append(f"{col} (top values):\n{top_values.to_string()}")
        summary_parts.append("Categorical column breakdown:\n" + "\n\n".join(cat_summary))

    if len(numeric_df.columns) >= 2:
        corr = numeric_df.corr(numeric_only=True).round(2)
        summary_parts.append(f"Correlation matrix (numeric columns):\n{corr.to_string()}")

    summary_parts.append(f"First 5 rows (sample):\n{df.head(5).to_string()}")

    return "\n\n".join(summary_parts)


def ask_claude(system_prompt: str, user_message: str) -> str:
    response = client.messages.create(
        model=MODEL,
        max_tokens=1000,
        system=system_prompt,
        messages=[{"role": "user", "content": user_message}],
    )
    return response.content[0].text


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
st.title("📊 AI-Powered Data Insights Assistant")
st.caption("Upload a CSV/Excel file → get instant AI-generated analysis → ask follow-up questions")

uploaded_file = st.file_uploader("Upload a CSV or Excel file", type=["csv", "xlsx"])

if uploaded_file:
    if uploaded_file.name.endswith(".csv"):
        df = pd.read_csv(uploaded_file)
    else:
        df = pd.read_excel(uploaded_file)

    st.subheader("Preview")
    st.dataframe(df.head(20), use_container_width=True)

    # Cache the summary + chat history in session state so we don't
    # regenerate it (and burn API calls) on every Streamlit rerun.
    if "data_summary" not in st.session_state or st.session_state.get("file_name") != uploaded_file.name:
        st.session_state.data_summary = build_data_summary(df)
        st.session_state.file_name = uploaded_file.name
        st.session_state.messages = []

    if st.button("Generate AI Insights", type="primary"):
        with st.spinner("Analyzing your data..."):
            system_prompt = (
                "You are a data analyst assistant. You will be given a statistical "
                "summary of a dataset (not the raw file). Write a concise insights "
                "report covering: 1) key trends, 2) notable anomalies or outliers, "
                "3) data quality issues (missing values, etc.), and 4) 2-3 questions "
                "worth investigating further. Use plain business language, not jargon."
            )
            insights = ask_claude(system_prompt, st.session_state.data_summary)
            st.session_state.insights = insights

    if "insights" in st.session_state:
        st.subheader("AI-Generated Insights")
        st.markdown(st.session_state.insights)

    st.divider()
    st.subheader("Ask a question about your data")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    question = st.chat_input("e.g. Which column has the strongest correlation with sales?")
    if question:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                system_prompt = (
                    "You are a data analyst assistant answering questions about a "
                    "dataset. You are given a statistical summary of the data below. "
                    "Answer only based on this summary. If the summary doesn't contain "
                    "enough information to answer precisely, say so instead of guessing.\n\n"
                    f"DATA SUMMARY:\n{st.session_state.data_summary}"
                )
                answer = ask_claude(system_prompt, question)
                st.markdown(answer)

        st.session_state.messages.append({"role": "assistant", "content": answer})
else:
    st.info("Upload a file to get started. No sample file? Try any CSV with sales, survey, or ops data.")
